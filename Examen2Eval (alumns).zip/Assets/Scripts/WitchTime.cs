using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WitchTime : MonoBehaviour
{
    // Update is called once per frame
    void Update()
    {

    }
}
